<!DOCTYPE html>
<html>
<head>
  <!-- Head -->
  <?php echo $__env->make('admin.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- /.head -->

  <!-- Style -->
  <?php echo $__env->yieldContent('style'); ?>
  <!-- /.style -->

</head>
<body class="hold-transition skin-purple-light sidebar-mini">
  <!-- Site wrapper -->
  <div class="wrapper">

    <!-- Header -->
    <header class="main-header">
      <?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <!-- /.header -->

    <!-- Sidebar -->
    <aside class="main-sidebar">
      <?php echo $__env->make('admin.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </aside>
    <!-- /.sidebar -->


    <!-- Content Wrapper -->
    <div class="content-wrapper">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- /.content-wrapper -->

    <?php echo $__env->make('admin.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </div>
  <!-- ./wrapper -->

  <!-- Flash Notification -->
  <?php echo $__env->make('admin.includes.flash_notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- /.flash notification -->

  <!-- Scripts -->
  <?php echo $__env->make('admin.includes.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- /.scripts -->

  <!-- Scripts -->
  <?php echo $__env->yieldContent('script'); ?>
  <!-- /.scripts -->
</body>
</html>
