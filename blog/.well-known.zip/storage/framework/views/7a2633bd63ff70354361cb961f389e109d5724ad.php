
<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="home-news-block block-no-space">
		<div class="crumb inner-page-crumb">
			<ul>
				<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
				<li><a href="<?php echo e(route('dashboard.dashboardPage')); ?>">Dashboard</a></li>
			</ul>
		</div>

		<div class="about-us">
			<h3>Recent Comments</h3>

			<div class="row">
				<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-12">
					<div class="post-grid-style">
						<div class="post-detail">
							<h2><a href="<?php echo e(route('detailsPage', $comment->post->post_slug)); ?>" title="maro news"><?php echo e($comment->post->post_title); ?></a></h2>
							<ul class="post-meta3">
								<li><i class="ti-time"></i><?php echo e(date("d F Y - h:ia", strtotime($comment->created_at))); ?></li>
							</ul>
							<p><?php echo $comment->comment; ?></p>
							<?php if($comment->publication_status == 1): ?>
							<button class="btn btn-success btn-xs">Published</button>
							<?php else: ?>
							<button class="btn btn-warning btn-xs">Unpublished</button>
							<?php endif; ?>
							<a href="<?php echo e(route('detailsPage', $comment->post->post_slug)); ?>" class="readmore"><i class="ti-more-alt"></i></a>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>

		<div class="row postgrid-horiz grid-style-2">
			<?php echo e($comments->links()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
	<?php echo $__env->make('web.includes.user_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>