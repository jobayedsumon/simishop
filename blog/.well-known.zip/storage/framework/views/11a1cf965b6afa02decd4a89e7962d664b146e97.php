<div class="col-md-4">
    <aside>
     <!--START NEWSLETTER-->
     <div class="widget newsletter">
        <form data-parsley-validate action="<?php echo e(route('searchRoute')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="search_keywords" class="newsletter-email" placeholder="ex: post title" required>
            <button class="newsletter-subscribe" type="submit"><i class="fa fa-search"></i> Search</button>
        </form>
        <?php if($errors->has('search_keywords')): ?>
        <p class="text-center text-danger" style="font-size: 12px; padding: 5px 0px;"><?php echo e($errors->first('search_keywords')); ?></p>
        <?php endif; ?>
    </div>
    <!--/END NEWSLETTER-->

  <!--START POPULAR CATEGORIES-->
  <div class="widget">
    <div class="widget-title">
        <h4>
            <i class="fa fa-rocket"></i>
            All Categories
        </h4>
    </div>
    <ul class="widget-popular-cat">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('categoryPage', $category->id)); ?>" title="<?php echo e($category->category_name); ?>"><i class="fa fa-angle-right"></i><?php echo e($category->category_name); ?><span class="cat-count-1"><?php echo e($category->post()->count()); ?></span></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<!--/END POPULAR CATEGORIES-->

<!--START NEWSLETTER-->
<div class="widget newsletter">
    <div class="widget-title">
        <h4>
            <i class="ti-email"></i>
            NEWSLETTER
        </h4>
    </div>
    <div class="subscribe-image">
        <img src="<?php echo e(asset('public/web')); ?>/images/newsletter.png" alt="Newsletter">
        <p>Subscribe our newsletter to stay updated.</p>
    </div>
    <form data-parsley-validate id="subscribe_add_form" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="text" name="email" class="newsletter-email" placeholder="ex: mail@mail.com" required>
        <button class="newsletter-subscribe" name="subscribe" type="button" id="store-button">Subscribe</button>
    </form>
    <p class="text-center text-danger" id="email-error"></p>
    <p class="text-center text-success" id="email-success"></p>
</div>
<!--/END NEWSLETTER-->

<!--START TAGS-->
<div class="widget">
    <div class="widget-title">
        <h4>
            <i class="ti-tag"></i>
            Tags
        </h4>
    </div>
    <ul class="tags-cloud">
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('tagPage', $tag->id)); ?>" title="<?php echo e($tag->tag_name); ?>"><?php echo e($tag->tag_name); ?> (<?php echo e($tag->posts()->count()); ?>)</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<!--/END TAGS-->

<!--Facebook Page-->
<?php if(!empty($setting->facebook)): ?>
    <div class="widget">
        <div class="fb-page" data-href="<?php echo e($setting->facebook); ?>" data-tabs="timeline" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
            <blockquote cite="<?php echo e($setting->facebook); ?>" class="fb-xfbml-parse-ignore">
                <a href="<?php echo e($setting->facebook); ?>"><?php echo e($setting->website_title); ?></a>
            </blockquote>
        </div>
        <div id="fb-root"></div>
        <script type="text/javascript">
            (function(d, s, id) {
              var js, fjs = d.getElementsByTagName(s)[0];
              if (d.getElementById(id)) return;
              js = d.createElement(s); js.id = id;
              js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=1227264524030761&autoLogAppEvents=1';
              fjs.parentNode.insertBefore(js, fjs);
          }(document, 'script', 'facebook-jssdk'));
      </script>
  </div>
  <?php endif; ?>
  <!--/Facebook Page-->

</aside>
</div>