<?php
use Carbon\Carbon;
?>



<?php $__env->startSection('title', $post->meta_title); ?>
<?php $__env->startSection('keywords', $post->meta_keywords); ?>
<?php $__env->startSection('description', $post->meta_description); ?>

<?php $__env->startSection('style'); ?>
<style type="text/css">
iframe {
	margin: 20px 0px;
}
.category {
	color: #9E9E9E;
}
.category:hover {
	color: #757575;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="home-news-block block-no-space">
		<div class="crumb inner-page-crumb">
			<ul>
				<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
				<li><a href="<?php echo e(route('dashboard.dashboardPage')); ?>">Dashboard</a></li>
				<li><a href="<?php echo e(route('dashboard.viewPostPage', $post->post_slug)); ?>"><?php echo e($post->post_title); ?></a></li>
			</ul>
		</div>

		<div class="about-us">
			<div class="row">
				<div class="col-md-12">
					<p class="text-warning pull-left">Post Status Unpublished</p>
					<a href="<?php echo e(route('dashboard.dashboardPage')); ?>" class="btn btn-primary pull-right btn-flat"><i class="fa fa-dashboard"></i> Dashboard</a>
				</div>
			</div>
			<hr>
			<div class="row">


				<div class="col-md-12">
					<div class="post-grid-style">
						<div class="post-detail">
							<h2><a><?php echo e($post->post_title); ?></a></h2>
							<ul class="post-meta3">
								<li><i class="ti-time"></i><?php echo e(date("d F Y - h:ia", strtotime($post->created_at))); ?></li>
								<li><i class="ti-comment"></i><?php echo e($post->comment->count()); ?></li>
								<li><i class="ti-eye"></i><?php echo e($post->view_count); ?></li>
							</ul>
							<div class="single-avatar">
								<img src="<?php echo e(get_featured_image_thumbnail_url($post->featured_image)); ?>" alt="maro news">
							</div>
							<p><?php echo $post->post_details; ?></p>
							<?php if(!empty($post->youtube_video_url)): ?>
							<iframe width="100%" height="420" src="<?php echo e($post->youtube_video_url); ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
							<?php endif; ?>
							<ul class="tag">
								<li><span><i class="fa fa-tags" aria-hidden="true"></i></span></li>
								<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a href="<?php echo e(route('tagPage', $tag->id)); ?>" title="<?php echo e($tag->tag_name); ?>"><?php echo e($tag->tag_name); ?></a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.user_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>