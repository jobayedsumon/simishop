<?php $__env->startSection('title', 'My Blog'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.contact-form {
	float: left;
	width: 100%;
	border: 0px;
	padding: 0px;
	margin-top: 0px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="home-news-block block-no-space">
		<div class="crumb inner-page-crumb">
			<ul>
				<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
				<li><a href="<?php echo e(route('dashboard.dashboardPage')); ?>">Dashboard</a> / </li>
				<li><a href="<?php echo e(route('dashboard.editPasswordPage')); ?>">Change Password</a></li>
			</ul>
		</div>

		<div class="about-us">
			<div class="contact-form">
				<div class="single-title">
					<h4>Change Password</h4>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<?php if(!empty(Session::get('message'))): ?>
						<p style="color: #5cb85c"><?php echo e(Session::get('message')); ?></p>
						<?php elseif(!empty(Session::get('exception'))): ?>
						<p style="color: #d9534f"><?php echo e(Session::get('exception')); ?></p>
						<?php else: ?>
						<p>Required fields are marked <span class="required">*</span></p>
						<?php endif; ?>
					</div>
					<form data-parsley-validate action="<?php echo e(route('dashboard.updatePasswordPage')); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="col-md-12<?php echo e($errors->has('current_password') ? ' has-error' : ''); ?>">
							<label>Current Password <span class="required">*</span></label>
							<input id="current_password" type="password" name="current_password" required>
							<?php if($errors->has('current_password')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('current_password')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="col-md-12<?php echo e($errors->has('new_password') ? ' has-error' : ''); ?>">
							<label>New Password <span class="required">*</span></label>
							<input id="new_password" type="password" name="new_password" required minlength="8">
							<?php if($errors->has('new_password')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('new_password')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="col-md-12<?php echo e($errors->has('new_password_confirmation') ? ' has-error' : ''); ?>">
							<label>Confirm New Password <span class="required">*</span></label>
							<input id="new_password_confirm" type="password" name="new_password_confirmation" required minlength="8">
						</div>
						<div class="col-sm-12">
							<button type="submit">Update <i class="fa fa-angle-right"></i></button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.user_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>