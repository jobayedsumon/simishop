<?php $__env->startSection('title', 'My Blog'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.btn { border-radius: 0px }
.tag-grid-style { margin: 5px 0px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
			<li><a class="active">Tags</a></li>
		</ul>
	</div>
	<div class="home-news-block block-no-space">
		<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-sm-3 tag-area">
			<div class="tag-grid-style">
				<a href="<?php echo e(route('tagPage', $tag->id)); ?>" class="btn btn-primary btn-block"><?php echo e($tag->tag_name); ?> (<?php echo e($tag->posts()->count()); ?>)</a>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>