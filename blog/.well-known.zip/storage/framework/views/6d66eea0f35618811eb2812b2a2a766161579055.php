
<?php $__env->startSection('title', 'Categories'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.btn { border-radius: 0px }
.category-grid-style { margin: 5px 0px; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
			<li><a class="active">Categories</a></li>
		</ul>
	</div>
	<div class="home-news-block block-no-space">
		<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-sm-3">
			<div class="category-grid-style">
				<a href="<?php echo e(route('categoryPage', $category->id)); ?>" class="btn btn-primary btn-block"><?php echo e($category->category_name); ?> (<?php echo e($category->post->count()); ?>)</a>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>