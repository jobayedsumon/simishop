<?php
use Carbon\Carbon;
?>



<?php $__env->startSection('title', $post->meta_title); ?>
<?php $__env->startSection('keywords', $post->meta_keywords); ?>
<?php $__env->startSection('description', $post->meta_description); ?>

<?php $__env->startSection('style'); ?>
<!-- Social Share: http://js-socials.com/demos/ -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/web/jssocials/jssocials.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/web/jssocials/jssocials-theme-flat.css')); ?>">
<style type="text/css">
	iframe {
		margin: 20px 0px;
	}
	.category {
		color: #9E9E9E;
	}
	.category:hover {
		color: #757575;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
			<li><a href="<?php echo e(route('categoryPage', $post->category->id)); ?>" title="<?php echo e($post->category->category_name); ?>"><?php echo e($post->category->category_name); ?></a> / </li>
			<li><a class="active"><?php echo e($post->post_title); ?></a></li>
		</ul>
	</div>
	<div class="blog-single">
		<div class="post-head">
			<h1><?php echo e($post->post_title); ?></h1>
			<div class="single-post-info">
				<div class="pull-left post-author">
					<?php if(!empty($post->user->avatar)): ?>
					<img alt="<?php echo e($post->user->name); ?>" src="<?php echo e(asset('public/avatar/' . $post->user->avatar)); ?>" width="35px">
					<?php else: ?>
					<img alt="<?php echo e($post->user->name); ?>" src="<?php echo e(get_gravatar($post->user->email)); ?>" width="35px">
					<?php endif; ?>
					By <a href="<?php echo e(route('authorProfilePage', $post->user->username)); ?>" title=""><?php echo e($post->user->name); ?></a>
					<span class="spliator">ــ</span>
					Last Update <a><?php echo e(date("d F Y", strtotime($post->post_date))); ?></a>
				</div>

				<ul class="views-comments pull-right">
					<li class="po-views"><i class="fa fa-eye"></i><?php echo e($post->view_count); ?></li>
					<li><i class="fa fa-comments"></i><?php echo e($post->comment->count()); ?></li>
				</ul>
			</div>
		</div>
		<div id="shareNative"></div>
		<div id="shareButtonLabel"></div>
		<!-- <ul class="share-links">
			<li><a href="#" title="" class="facebook"><i class="fa fa-facebook"></i> Facebook <b>563</b></a></li>
			<li><a href="#" title="" class="twitter"><i class="fa fa-twitter"></i> Twitter <b>650</b></a></li>
			<li><a href="#" title="" class="google"><i class="fa fa-google"></i> Google+</a></li>
			<li><a href="#" title="" class="pinterest"><i class="fa fa-pinterest-p"></i> Pinterest</a></li>
			<li><a href="#" title="" class="flickr"><i class="fa fa-flickr"></i> Flickr</a></li>
			<li><a href="#" title="" class="linkedin"><i class="fa fa-linkedin"></i> Linkedin</a></li>
			<li><a href="#" title="" class="whatsapp"><i class="fa fa-whatsapp"></i> Whatsapp</a></li>
		</ul> -->
		<div class="single-avatar">
			<img src="<?php echo e(get_featured_image_thumbnail_url($post->featured_image)); ?>" alt="maro news">
		</div>
		<div class="single-post-detail">
			<a title="<?php echo e($post->post_title); ?>" class="category"><?php echo e($post->post_title); ?></a>
			<?php echo $post->post_details; ?>

			<?php if(!empty($post->youtube_video_url)): ?>
			<iframe width="100%" height="420" src="<?php echo e($post->youtube_video_url); ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
			<?php endif; ?>
			<ul class="tag">
				<li><span><i class="fa fa-tags" aria-hidden="true"></i></span></li>
				<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="<?php echo e(route('tagPage', $tag->id)); ?>" title="<?php echo e($tag->tag_name); ?>"><?php echo e($tag->tag_name); ?></a></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
			<div class="author">
				<div class="author-avatar">
					<?php if(!empty($post->user->avatar)): ?>
					<img alt="<?php echo e($post->user->name); ?>" src="<?php echo e(asset('public/avatar/' . $post->user->avatar)); ?>" width="90px">
					<?php else: ?>
					<img alt="<?php echo e($post->user->name); ?>" src="<?php echo e(get_gravatar($post->user->email)); ?>" width="90px">
					<?php endif; ?>
				</div>
				<div class="author-about">
					<h4><a href="<?php echo e(route('authorProfilePage', $post->user->username)); ?>"><?php echo e($post->user->name); ?></a></h4>
					<p><?php echo e($post->user->about); ?> &nbsp; </p>
					<ul>
						<?php if($post->user->facebook): ?>
						<li><a href="<?php echo e($post->user->facebook); ?>" target="_blank" title="facebook" class="facebook"><i class="fa fa-facebook"></i></a></li>
						<?php endif; ?>
						<?php if($post->user->twitter): ?>
						<li><a href="<?php echo e($post->user->twitter); ?>" target="_blank" title="twitter" class="twitter"><i class="fa fa-twitter"></i></a></li>
						<?php endif; ?>
						<?php if($post->user->google_plus): ?>
						<li><a href="<?php echo e($post->user->google_plus); ?>" target="_blank" title="google" class="google"><i class="fa fa-google-plus"></i></a></li>
						<?php endif; ?>
						<?php if($post->user->linkedin): ?>
						<li><a href="<?php echo e($post->user->linkedin); ?>" target="_blank" title="linkedin" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>

	<div class="single-related">
		<div class="single-title">
			<h4><i class="fa fa-thumbs-o-up"></i> You May Also Like</h4>
		</div>
		<div class="category-recent-post">
			<?php $__currentLoopData = $related_posts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="progress-unit">
				<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 col-sm-12">
					<div class="pp-trending-grid">
						<img src="<?php echo e(get_featured_image_thumbnail_url($related_post->featured_image)); ?>" alt="maro news">
						<div class="pp-trend-meta">
							<h5><a href="<?php echo e(route('detailsPage', $related_post->post_slug)); ?>" title=""><?php echo e(str_limit($related_post->post_title, 50)); ?></a></h5>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>

	<div class="space no-top comments-sec">
		<div class="single-title">
			<h4><i class="fa fa-comments"></i> <?php echo e($post->comment->count()); ?> Comments.</h4>
		</div>
		<ul>
			<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<div class="comment">
					<?php if(!empty($comment->user->avatar)): ?>
					<img alt="<?php echo e($comment->user->name); ?>" src="<?php echo e(asset('public/avatar/' . $comment->user->avatar)); ?>" width="70px">
					<?php else: ?>
					<img alt="<?php echo e($comment->user->name); ?>" src="<?php echo e(get_gravatar($comment->user->email)); ?>" width="70px">
					<?php endif; ?>
					<div class="comment-detail">
						<h4><a title="" href="#"><?php echo e($comment->user->name); ?></a></h4><span><?php echo e(date("d F Y - h:ia", strtotime($comment->created_at))); ?></span>
						<p><?php echo $comment->comment; ?></p>
						<?php if(Auth::check()): ?>
						<a title="Replay" class="reply" data-id="<?php echo e($comment->id); ?>"><i class="fa fa-reply"></i>Reply</a>
						<?php endif; ?>
					</div>
				</div>
				<?php ($sub_comments = App\Comment::where(['post_id' => $post->id, 'parent_comment_id' => $comment->id, 'publication_status' => 1])->orderBy('id', 'asc')->get()); ?>
				<?php $__currentLoopData = $sub_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<ul>
					<li>
						<div class="comment">
							<?php if(!empty($sub_comment->user->avatar)): ?>
							<img alt="<?php echo e($sub_comment->user->name); ?>" src="<?php echo e(asset('public/avatar/' . $sub_comment->user->avatar)); ?>" width="70px">
							<?php else: ?>
							<img alt="<?php echo e($sub_comment->user->name); ?>" src="<?php echo e(get_gravatar($sub_comment->user->email)); ?>" width="70px">
							<?php endif; ?>
							<div class="comment-detail">
								<h4><a title="" href="#"><?php echo e($sub_comment->user->name); ?></a></h4><span><?php echo e(date("d F Y - h:ia", strtotime($sub_comment->created_at))); ?></span>
								<p><?php echo $sub_comment->comment; ?></p>
								<?php if(Auth::check()): ?>
								<a title="Replay" class="reply" data-id="<?php echo e($comment->id); ?>"><i class="fa fa-reply"></i>Reply</a>
								<?php endif; ?>
							</div>
						</div>
					</li>
				</ul>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<div id="reply_form_<?php echo e($comment->id); ?>"></div>

			</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<div class="contact-form">
		<div class="single-title">
			<h4>leave a comment</h4>
		</div>

		<div class="row">
			<div class="col-sm-12">
				<?php if(!empty(Session::get('message'))): ?>
				<p style="color: #5cb85c"><?php echo e(Session::get('message')); ?></p>
				<?php elseif(!empty(Session::get('exception'))): ?>
				<p style="color: #d9534f"><?php echo e(Session::get('exception')); ?></p>
				<?php endif; ?>
			</div>
			<?php if(Auth::check()): ?>
			<form data-parsley-validate action="<?php echo e(route('commentRoute', $post->id)); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<div class="col-sm-12<?php echo e($errors->has('comment') ? ' has-error' : ''); ?>">
					<label>Comment <span class="required">*</span></label>
					<textarea name="comment" cols="30" rows="10" required></textarea>
					<?php if($errors->has('comment')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('comment')); ?></strong>
					</span>
					<?php endif; ?>
				</div>
				<div class="col-sm-12">
					<button type="submit">Post Comment <i class="fa fa-angle-right"></i></button>
				</div>
			</form>
			<?php else: ?>
			<div class="col-sm-12">
				<p>You must login to post a comment. Already Member <a href="<?php echo e(route('login')); ?>">Login</a> | New <a href="<?php echo e(route('register')); ?>">Register</a></p>
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	$(document).ready(function() {
		$(".reply").click(function(){
			var comment_id = $(this).data("id");
			var id = '#reply_form_'+comment_id;

			var url = "<?php echo e(route('replayCommentRoute', 'comment_id')); ?>";
			url = url.replace("comment_id", comment_id);

			$(id).empty();
			$(id).append('<div class="contact-form" style="margin-bottom: 35px;"><div class="row"><form data-parsley-validate action="'+url+'" method="post"><?php echo e(csrf_field()); ?><input type="hidden" name="post_id" value="<?php echo e($post->id); ?>"><div class="col-sm-12"><label>Comment <span class="required">*</span></label><textarea name="comment" cols="30" rows="3" required></textarea></div><div class="col-sm-12"><button type="submit">Replay <i class="fa fa-angle-right"></i></button></div></form></div></div>');
		});
	});
</script>
<!-- Social Share: http://js-socials.com/demos/ -->
<script type="text/javascript" src="<?php echo e(asset('public/web/jssocials/jssocials.js')); ?>"></script>
<script type="text/javascript">
	$(function(){
		var url = 'clustercoding.com';
		$("#shareButtonLabel").jsSocials({
			url: url,
			text: "Google Search Page",
			showCount: false,
			showLabel: true,
			shareIn: "popup",
			shares: [
			"email",
			"twitter",
			"facebook",
			"googleplus",
			"linkedin",
			{ share: "pinterest", label: "Pin this" },
			"whatsapp"
			]
		});
	});
</script>
<script type="text/javascript">
	$(function(){
		$("#shareNative").jsSocials({
			showLabel: false,
			showCount: false,

			shares: [{
				renderer: function() {
					var $result = $("<div>");

					var script = document.createElement("script");
					script.text = "(function(d, s, id) {var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = \"//connect.facebook.net/ru_RU/sdk.js#xfbml=1&version=v2.3\"; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));";
					$result.append(script);

					$("<div>").addClass("fb-share-button")
					.attr("data-layout", "button_count")
					.appendTo($result);

					return $result;
				}
			}, {
				renderer: function() {
					var $result = $("<div>");

					var script = document.createElement("script");
					script.src = "https://apis.google.com/js/platform.js";
					$result.append(script);

					$("<div>").addClass("g-plus")
					.attr({
						"data-action": "share",
						"data-annotation": "bubble"
					})
					.appendTo($result);

					return $result;
				}
			}, {
				renderer: function() {
					var $result = $("<div>");

					var script = document.createElement("script");
					script.src = "//platform.linkedin.com/in.js";
					$result.append(script);

					$("<script>").attr({ type: "IN/Share", "data-counter": "right" })
					.appendTo($result);

					return $result;
				}
			}, {
				renderer: function() {
					var $result = $("<div>");

					var script = document.createElement("script");
					script.text = "window.twttr=(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],t=window.twttr||{};if(d.getElementById(id))return t;js=d.createElement(s);js.id=id;js.src=\"https://platform.twitter.com/widgets.js\";fjs.parentNode.insertBefore(js,fjs);t._e=[];t.ready=function(f){t._e.push(f);};return t;}(document,\"script\",\"twitter-wjs\"));";
					$result.append(script);

					$("<a>").addClass("twitter-share-button")
					.text("Tweet")
					.attr("href", "https://twitter.com/share")
					.appendTo($result);

					return $result;
				}
			}, {
				renderer: function() {
					var $result = $("<div>");

					var script = document.createElement("script");
					script.src = "//assets.pinterest.com/js/pinit.js";
					$result.append(script);

					$("<a>").append($("<img>").attr("//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_20.png"))
					.attr({
						href: "//www.pinterest.com/pin/create/button/?url=http%3A%2F%2Fjs-socials.com%2Fdemos%2F&media=%26quot%3Bhttp%3A%2F%2Fgdurl.com%2Fa653%26quot%3B&description=Next%20stop%3A%20Pinterest",
						"data-pin-do": "buttonPin",
						"data-pin-config": "beside",
						"data-pin-color":"red"
					})
					.appendTo($result);

					return $result;
				}
			}]
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>