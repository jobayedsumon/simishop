<?php ($user = Auth::user()); ?>
<div class="col-md-4">
	<aside>
		<div class="widget">
			<div class="media-body text-center">
				<?php if(!empty($user->avatar)): ?>
				<img src="<?php echo e(asset('public/avatar/' . $user->avatar)); ?>" class="media-object img-circle" style="width:80px; margin: 0 auto; padding-bottom: 10px;">
				<?php else: ?> 
				<img src="<?php echo e(get_gravatar($user->email)); ?>" class="media-object img-circle" style="width:80px; margin: 0 auto; padding-bottom: 10px;">
				<?php endif; ?>
				<h4 class="media-heading"><strong><?php echo e($user->name); ?></strong></h4>
				<?php if(isAdmin()): ?>
				<p class="text-success"><strong>Admin</strong></p>
				<a href="<?php echo e(route('admin.dashboardRoute')); ?>">Admin Dashboard</a>
				<?php else: ?>
				<p class="text-success"><strong>User</strong></p>
				<?php endif; ?>
			</div>
			<hr>
			<div>
				<div class="btn-group btn-group-justified">
					<div class="btn-group">
						<a href="<?php echo e(route('dashboard.editProfilePage')); ?>" class="tip btn btn-default btn-sm"><i class="fa fa-user"></i><span class="hidden-sm hidden-xs"> Edit Profile</span></a>
					</div><div class="btn-group">
						<a href="<?php echo e(route('dashboard.editPasswordPage')); ?>" class="tip btn btn-default btn-sm"><i class="fa fa-key"></i><span class="hidden-sm hidden-xs"> Change Password</span></a>
					</div>
				</div>
			</div>
			<hr>
			<div class="text-center"> 
				<?php if(!empty($user->facebook)): ?>
				<a href="<?php echo e($user->facebook); ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-facebook"></i></a>
				<?php endif; ?>
				<?php if(!empty($user->twitter)): ?>
				<a href="<?php echo e($user->twitter); ?>" target="_blank" class="btn btn-info btn-sm"><i class="fa fa-twitter"></i></a>
				<?php endif; ?>
				<?php if(!empty($user->google_plus)): ?>
				<a href="<?php echo e($user->google_plus); ?>" target="_blank" class="btn btn-danger btn-sm"><i class="fa fa-google-plus"></i></a>
				<?php endif; ?>
				<?php if(!empty($user->linkedin)): ?>
				<a href="<?php echo e($user->linkedin); ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-linkedin"></i></a>
				<?php endif; ?>
			</div>
			<hr>
			<ul class="contact-widget">
				<li>
					<span>Username</span>
					<ins><i class="ti-user"></i> <?php echo e($user->username); ?></ins>
				</li>
				<li>
					<span>Email Address</span>
					<ins><i class="ti-email"></i> <?php echo e($user->email); ?></ins>
				</li>
				<?php if(!empty($user->phone)): ?>
				<li>
					<span>Phone Number</span>
					<ins><i class="ti-mobile"></i> <?php echo e($user->phone); ?></ins>
				</li>
				<?php endif; ?>
				<?php if(!empty($user->address)): ?>
				<li>
					<span>Address</span>
					<ins><i class="ti-location-pin"></i> <?php echo e($user->address); ?></ins>
				</li>
				<?php endif; ?>
				<?php if(!empty($user->gender)): ?>
				<li>
					<span>Gender</span>
					<?php if($user->gender == 'm'): ?>
					<ins><i class="fa fa-male"></i> Male</ins>
					<?php else: ?>
					<ins><i class="fa fa-female"></i> Female</ins>
					<?php endif; ?>
				</li>
				<?php endif; ?>
				<?php if(!empty($user->about)): ?>
				<li>
					<span>About</span>
					<ins><i class="ti-user"></i> <?php echo e($user->about); ?></ins>
				</li>
				<?php endif; ?>
			</ul>
		</div>
	</aside>
</div>