<?php $__env->startSection('title', 'Add Post'); ?>

<?php $__env->startSection('style'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('public/admin/css/bootstrap-datepicker.min.css')); ?>">
<link href="<?php echo e(asset('public/admin/summernote/summernote.css')); ?>" rel="stylesheet">
<style type="text/css">
.form-control{
	border-radius: 0px;
	padding: 20px 12px;
}
.btn{
	border-radius: 0px;
}
.select2-container--default .select2-selection--multiple {
    border: 1px solid #ccc;
    border-radius: 0px;
    padding: 5px 3px;
}
.select2-container--default.select2-container--focus .select2-selection--multiple {
    border: solid #ccc 1px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="home-news-block block-no-space">
		<div class="crumb inner-page-crumb">
			<ul>
				<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
				<li><a href="<?php echo e(route('dashboard.dashboardPage')); ?>">Dashboard</a> / </li>
				<li><a href="<?php echo e(route('dashboard.addPostPage')); ?>">Add Post</a></li>
			</ul>
		</div>

		<?php ($user = Auth::user()); ?>

		<div class="about-us">
			<div class="row">
				<div class="col-sm-12">
					<h3 class="pull-left">Add Post</h3>
					<a href="<?php echo e(route('dashboard.dashboardPage')); ?>" class="btn btn-primary pull-right btn-flat"><i class="fa fa-dashboard"></i> Dashboard</a>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-sm-12" style="margin-bottom: 15px;">
					<?php if(!empty(Session::get('message'))): ?>
					<p style="color: #5cb85c"><?php echo e(Session::get('message')); ?></p>
					<?php elseif(!empty(Session::get('exception'))): ?>
					<p style="color: #d9534f"><?php echo e(Session::get('exception')); ?></p>
					<?php else: ?>
					<small>Required fields are marked <span class="required">*</span></small>
					<?php endif; ?>
				</div>
				<div class="col-sm-12">
					<form data-parsley-validate name="post_add_form" action="<?php echo e(route('dashboard.updatePprofilePage', $user->id)); ?>" method="post" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="form-group<?php echo e($errors->has('post_title') ? ' has-error' : ''); ?>">
							<label for="post_title">Post Title</label>
							<input type="text" name="post_title" class="form-control" id="post_title" value="<?php echo e(old('post_title')); ?>" placeholder="ex: post title">
							<?php if($errors->has('post_title')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('post_title')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('post_slug') ? ' has-error' : ''); ?>">
							<label for="post_slug">Post Slug</label>
							<input type="text" name="post_slug" class="form-control" id="username" value="<?php echo e(old('post_slug')); ?>" placeholder="ex: post_slug">
							<?php if($errors->has('post_slug')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('post_slug')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
							<label>Category Name <span class="required">*</span></label>
							<select name="category_id" id="category_id" class="form-control" required>
								<option value="" selected disabled style="color:black">Select One</option>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php if($errors->has('category_id')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('category_id')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('post_date') ? ' has-error' : ''); ?>">
							<label>Post Date <span class="required">*</span></label>
							<div class="input-group date">
								<div class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</div>
								<input type="text" name="post_date" class="form-control pull-right" id="post_date">
							</div>
							<?php if($errors->has('post_date')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('post_date')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('featured_image') ? ' has-error' : ''); ?>">
							<label>Featured Image</label>
							<input id="featured_image" type="file" name="featured_image" class="form-control">
							<?php if($errors->has('featured_image')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('featured_image')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('post_tags') ? ' has-error' : ''); ?>">
							<label>Post Tag <span class="required">*</span></label>
							<select class="form-control select2-post-tag" name="post_tags[]" multiple="multiple" id="post_tags">
								<option disabled>Select Tags</option>
								<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<?php if($errors->has('post_tags')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('post_tags')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('youtube_video_url') ? ' has-error' : ''); ?>">
							<label>Youtube Video URL</label>
							<input id="youtube_video_url" type="text" name="youtube_video_url" class="form-control" value="<?php echo e(old('youtube_video_url')); ?>" maxlength="250" placeholder="ex: https://www.youtube.com/watch?v=CSGiwf7KlrQ">
							<?php if($errors->has('youtube_video_url')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('youtube_video_url')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('post_details') ? ' has-error' : ''); ?>">
							<label>Post Details <span class="required">*</span></label>
							<textarea name="post_details" class="form-control summernote" id="post_details"><?php echo e(old('post_details')); ?></textarea>
							<?php if($errors->has('post_details')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('post_details')); ?></strong>
							</span>
							<?php endif; ?>
						</div>

						<div class="form-group<?php echo e($errors->has('meta_title') ? ' has-error' : ''); ?>">
							<label>Meta Title <span class="required">*</span></label>
							<input id="meta_title" type="text" name="meta_title" class="form-control" value="<?php echo e(old('meta_title')); ?>" required maxlength="250" placeholder="ex: meta title">
							<?php if($errors->has('meta_title')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('meta_title')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('meta_keywords') ? ' has-error' : ''); ?>">
							<label>Meta Keywords</label>
							<input id="meta_keywords" type="text" name="meta_keywords" class="form-control" value="<?php echo e(old('meta_keywords')); ?>" maxlength="250" placeholder="ex: meta, keywords">
							<?php if($errors->has('meta_keywords')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('meta_keywords')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<div class="form-group<?php echo e($errors->has('meta_description') ? ' has-error' : ''); ?>">
							<label>Meta Description <span class="required">*</span></label>
							<textarea name="meta_description" rows="5" class="form-control" required maxlength="260" placeholder="ex: meta description"><?php echo e(old('meta_description')); ?></textarea>
							<?php if($errors->has('meta_description')): ?>
							<span class="help-block">
								<strong><?php echo e($errors->first('meta_description')); ?></strong>
							</span>
							<?php endif; ?>
						</div>
						<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Add Post</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.user_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('.select2-post-tag').select2();
	});
</script>
<script type="text/javascript" src="<?php echo e(asset('public/admin/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript">
	$(function () {
		var date = new Date();
		//date.setDate(date.getDate()-1);
		$('#post_date').datepicker({
			autoclose: true,
			format: "yyyy-mm-dd",
			startDate: date,
		});
		$('#post_date').datepicker('setDate', 'now');
	});
</script>
<!-- Summernote editor -->
<script src="<?php echo e(asset('public/admin/summernote/summernote.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('.summernote').summernote({
			height: 200
		})
	});
</script>
<script type="text/javascript">
	document.forms['post_add_form'].elements['category_id'].value = "<?php echo e(old('category_id')); ?>";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>