<?php $__env->startSection('title', 'My Blog'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.form-control{
    border-radius: 0px;
    padding: 20px 12px;
}
.btn{
    border-radius: 0px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-6 col-md-offset-3">
    <div class="home-news-block block-no-space">
        <div class="about-us">
            <h3>Register</h3>
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('name')); ?>" placeholder="Email">
                    <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                    <label for="username">Username</label>
                    <input type="text" name="username" class="form-control" id="username" value="<?php echo e(old('username')); ?>" placeholder="Email">
                    <?php if($errors->has('username')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                    <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password">Password</label>
                    <input id="password" type="password" class="form-control" name="password">
                    <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="password-confirm">Confirm Password</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation">
                </div>
                <button type="submit" class="btn btn-info">Submit</button>
            </form>
            <p style="margin-top: 25px;">Already have an account? <a href="<?php echo e(route('login')); ?>">Login</a>.</p>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>