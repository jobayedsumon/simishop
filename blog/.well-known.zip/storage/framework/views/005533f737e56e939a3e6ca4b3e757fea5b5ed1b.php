
<?php $__env->startSection('title', 'Post'); ?>


<?php $__env->startSection('style'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('public/admin/css/bootstrap-datepicker.min.css')); ?>">
<style type="text/css">
.modal-body {
    position: relative;
    padding: 25px;
}
.modal-content {
    position: relative;
    background-color: #fff;
    border: 1px solid #999;
    border: 1px solid rgba(0,0,0,.2);
    border-radius: 6px;
    -webkit-box-shadow: 0 3px 9px rgba(0,0,0,.5);
    box-shadow: 0 3px 9px rgba(0,0,0,.5);
    background-clip: padding-box;
    outline: 0;
}
.select2-container--default .select2-selection--multiple .select2-selection__choice {
	background-color: #3c8dbc ;
	border: 1px solid #367fa9;
	border-radius: 4px;
	cursor: default;
	float: left;
	margin-right: 5px;
	margin-top: 5px;
	padding: 0 5px;
}
.select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
	color: black;
	cursor: pointer;
	display: inline-block;
	font-weight: bold;
	margin-right: 4px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page header -->

<section class="content-header">
	<h1>
		POST
	</h1>
	<ol class="breadcrumb">
		<li><a href="<?php echo e(route('admin.dashboardRoute')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>
		<li><a href="<?php echo e(route('admin.posts.index')); ?>">Post</a></li>
		<li class="active">Add Post</li>
	</ol>
</section>
<!-- /.page header -->

<!-- Main content -->
<section class="content">
	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Add Post</h3>

			<div class="box-tools">
				<a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-info btn-sm btn-flat"><i class="fa fa-list"></i> Manage Posts</a>
			</div>
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<form name="post_add_form" class="form-horizontal" action="<?php echo e(route('admin.posts.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<div class="form-group<?php echo e($errors->has('post_title') ? ' has-error' : ''); ?>">
					<label for="post_title" class="col-md-2 control-label">Post Title</label>
					<div class="col-md-9">
						<input type="text" name="post_title" class="form-control" id="post_title" value="<?php echo e(old('post_title')); ?>" placeholder="ex: post title">
						<?php if($errors->has('post_title')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('post_title')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('post_slug') ? ' has-error' : ''); ?>">
					<label for="post_slug" class="col-md-2 control-label">Post Slug</label>
					<div class="col-md-9">
						<input type="text" name="post_slug" class="form-control" id="post_slug" value="<?php echo e(old('post_slug')); ?>" placeholder="ex: post-slug">
						<?php if($errors->has('post_slug')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('post_slug')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
					<label for="category_id" class="col-md-2 control-label">Category Name</label>
					<div class="col-md-5">
						<select name="category_id" class="form-control" id="category_id">
							<option value="" selected disabled>Select One</option>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('category_id')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('category_id')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('post_date') ? ' has-error' : ''); ?>">
					<label for="post_date" class="col-md-2 control-label">Post Date</label>
					<div class="col-md-5">
						<div class="input-group date">
							<div class="input-group-addon">
								<i class="fa fa-calendar"></i>
							</div>
							<input type="text" name="post_date" class="form-control pull-right" id="post_date">
						</div>
						<?php if($errors->has('post_date')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('post_date')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('publication_status') ? ' has-error' : ''); ?>">
					<label for="publication_status" class="col-md-2 control-label">Publication Status</label>
					<div class="col-md-5">
						<select name="publication_status" class="form-control" id="publication_status">
							<option value="" selected disabled>Select One</option>
							<option value="1">Published</option>
							<option value="0">Unpublished</option>
						</select>
						<?php if($errors->has('publication_status')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('publication_status')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('is_featured') ? ' has-error' : ''); ?>">
					<label for="is_featured" class="col-md-2 control-label">Is Featured ?</label>
					<div class="col-md-9">
						<label class="radio-inline">
							<input type="radio" name="is_featured" id="is_featured_1" value="1" <?php echo e(old('is_featured') == 1 ? 'checked' : ''); ?>>Yes
						</label>
						<label class="radio-inline">
							<input type="radio" name="is_featured" id="is_featured_2" value="0" <?php echo e(old('is_featured') == 0 ? 'checked' : ''); ?>>No
						</label>
						<?php if($errors->has('is_featured')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('is_featured')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('featured_image') ? ' has-error' : ''); ?>">
					<label for="featured_image" class="col-md-2 control-label">Featured Image</label>
					<div class="col-md-5">
						<input type="file" name="featured_image" id="featured_image" class="form-control">
						<p class="help-block">Example block-level help text here.</p>
						<?php if($errors->has('featured_image')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('featured_image')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>

				<div class="form-group<?php echo e($errors->has('post_tags') ? ' has-error' : ''); ?>">
					<label for="post_tags" class="col-md-2 control-label">Post Tag</label>
					<div class="col-md-9">
						<select class="form-control select2-post-tag" name="post_tags[]" multiple="multiple" id="post_tags">
							<option disabled>Select Tags</option>
							<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						<?php if($errors->has('post_tags')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('post_tags')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>

				<div class="form-group<?php echo e($errors->has('youtube_video_url') ? ' has-error' : ''); ?>">
					<label for="youtube_video_url" class="col-md-2 control-label">Youtube Video URL</label>
					<div class="col-md-9">
						<input type="text" name="youtube_video_url" class="form-control" id="youtube_video_url" value="<?php echo e(old('youtube_video_url')); ?>" placeholder="ex: https://www.youtube.com/watch?v=CSGiwf7KlrQ">
						<?php if($errors->has('youtube_video_url')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('youtube_video_url')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('post_details') ? ' has-error' : ''); ?>">
					<label for="post_details" class="col-md-2 control-label">Post Details</label>
					<div class="col-md-9">
						<textarea name="post_details" class="form-control summernote" id="post_details"><?php echo e(old('post_details')); ?></textarea>
						<?php if($errors->has('post_details')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('post_details')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>

				<div class="form-group<?php echo e($errors->has('post_title') ? ' has-error' : ''); ?>">
					<label class="col-md-2 control-label"></label>
					<div class="col-md-9">
						<div class="bs-callout bs-callout-success">
							<h4>SEO Information</h4>
						</div>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('meta_title') ? ' has-error' : ''); ?>">
					<label for="meta_title" class="col-md-2 control-label">Meta Title</label>
					<div class="col-md-9">
						<input type="text" name="meta_title" class="form-control" id="meta_title" value="<?php echo e(old('meta_title')); ?>" placeholder="ex: post title">
						<?php if($errors->has('meta_title')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('meta_title')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('meta_keywords') ? ' has-error' : ''); ?>">
					<label for="meta_keywords" class="col-md-2 control-label">Meta Keywords</label>
					<div class="col-md-9">
						<input type="text" name="meta_keywords" class="form-control" id="meta_keywords" value="<?php echo e(old('meta_keywords')); ?>" placeholder="ex: post, title">
						<?php if($errors->has('meta_keywords')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('meta_keywords')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group<?php echo e($errors->has('meta_description') ? ' has-error' : ''); ?>">
					<label for="meta_description" class="col-md-2 control-label">Meta Description</label>
					<div class="col-md-9">
						<textarea name="meta_description" id="meta_description" class="form-control" rows="3" placeholder="ex: post dscription"><?php echo e(old('meta_description')); ?></textarea>
						<?php if($errors->has('meta_description')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('meta_description')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group">
					<div class="col-md-offset-2 col-md-10">
						<button type="submit" class="btn btn-info btn-flat">Add Post</button>
					</div>
				</div>
			</form>
		</div>
		<!-- /.box-body -->
		<div class="box-footer clearfix">
		</div>
	</div>
</section>
<!-- /.main content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('.select2-post-tag').select2();
	});
</script>
<script type="text/javascript" src="<?php echo e(asset('public/admin/js/bootstrap-datepicker.min.js')); ?>"></script>
<script type="text/javascript">
	$(function () {
		var date = new Date();
		//date.setDate(date.getDate()-1);
        $('#post_date').datepicker({
            autoclose: true,
            format: "yyyy-mm-dd",
            startDate: date,
        });
        $('#post_date').datepicker('setDate', 'now');
	});
</script>
<script type="text/javascript">
	$(function(){
	$('.summernote').summernote({
		height: 200
	})
})
</script>
<script type="text/javascript">
	document.forms['post_add_form'].elements['category_id'].value = "<?php echo e(old('category_id')); ?>";
	document.forms['post_add_form'].elements['publication_status'].value = "<?php echo e(old('publication_status')); ?>";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>