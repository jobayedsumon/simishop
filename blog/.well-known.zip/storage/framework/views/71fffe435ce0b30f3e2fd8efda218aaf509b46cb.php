<?php $__env->startSection('title', 'My Blog'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (Image) */
.modal-content {
    margin: auto;
    display: block;
    width: 100%;
    max-width: 700px;
    background-color:transparent;
    border:0px solid #999;
    border:0px solid rgba(0,0,0,0);
    outline:0;
    -webkit-box-shadow:0 0px 0px rgba(0,0,0,0);
    box-shadow:0 0px 0px rgba(0,0,0,0)
}
.modal-header {
	border: 0px;
	}
.caption {
    margin: auto;
    display: block;
    width: 100%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
}
.close {
    color: #f1f1f1;
    font-size: 40px;
    font-weight: bold;
    transition: 0.3s;
}

.close:hover,
.close:focus {
    color: #bbb;
    text-decoration: none;
    cursor: pointer;
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
			<li><a href="<?php echo e(route('galleryPage')); ?>">Gallery</a></li>
		</ul>
	</div>
	<div class="home-news-block block-no-space">
		<div class="row postgrid-horiz grid-style-2">
			<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-sm-4">
				<div class="featured-post">
					<div class="featured-avatar">
						<a class="post-music view-image" data-id="<?php echo e($gallery->id); ?>" title="<?php echo e($gallery->caption); ?>"><i class="ti-image"></i></a>
						<img src="<?php echo e(get_gallery_image_url($gallery->image)); ?>" alt="<?php echo e($gallery->caption); ?>">
					</div>
					<div class="featured-meta small">
						<h2><a title="<?php echo e($gallery->caption); ?>"><?php echo e($gallery->caption); ?></a></h2>
						<ul class="post-info">
							<li><a href="<?php echo e(route('authorProfilePage', $gallery->user->username)); ?>" title="<?php echo e($gallery->caption); ?>"><i class="ti-user"></i><?php echo e($gallery->user->name); ?></a></li>
						</ul>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="pagination" style="margin-top: 25px;"><?php echo e($galleries->links()); ?></div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade bs-example-modal-lg" id="view-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close"><span aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<img id="view-image" width="100%">
				<br>
				<span class="caption" id="view-caption"></span>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	$(document).ready(function() {
		$(".view-image").click(function(){
			var id = $(this).data("id");
			var url = "<?php echo e(route('getGalleryRoute', 'id')); ?>";
			url = url.replace("id", id);
			$.ajax({
				url: url,
				method: "GET",
				dataType: "json",
				success:function(data){
					var src = '<?php echo e(get_gallery_image_url()); ?>/';
					$('#view-modal').modal('show');
					$('#view-caption').text(data['caption']);
					$("#view-image").attr("src", src+data['image']);
				}
			});
		});
		$(".close").click(function(){
			$('#view-modal').modal('toggle');
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>