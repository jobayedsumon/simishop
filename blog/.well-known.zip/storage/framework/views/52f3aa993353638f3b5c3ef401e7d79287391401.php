<?php $__env->startSection('title', $user->name); ?>


<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="home-news-block block-no-space">
		<div class="crumb inner-page-crumb">
			<ul>
				<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
				<li><a href="<?php echo e(route('authorProfilePage', $user->username)); ?>"><?php echo e($user->name); ?></a></li>
			</ul>
		</div>

		<div class="about-us">
			<h3>Author Recent Posts</h3>

			<div class="row">
				<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-12">
					<div class="post-grid-style">
						<div class="post-detail">
							<h2><a href="<?php echo e(route('detailsPage', $post->post_slug)); ?>" title="maro news"><?php echo e($post->post_title); ?></a></h2>
							<ul class="post-meta3">
								<li><i class="ti-time"></i><?php echo e(date("d F Y - h:ia", strtotime($post->created_at))); ?></li>
							</ul>
							<p><?php echo str_limit($post->post_details, 150); ?></p>
							<a href="<?php echo e(route('detailsPage', $post->post_slug)); ?>" class="readmore"><i class="ti-more-alt"></i></a>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>

		<div class="row postgrid-horiz grid-style-2">
			<?php echo e($posts->links()); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<div class="col-md-4">
	<aside>
		<div class="widget">
			<div class="media-body text-center">
				<?php if(!empty($user->avatar)): ?>
				<img src="<?php echo e(asset('public/avatar/' . $user->avatar)); ?>" class="media-object img-circle" style="width:80px; margin: 0 auto; padding-bottom: 10px;">
				<?php else: ?>
				<img src="<?php echo e(get_gravatar($user->email)); ?>" class="media-object img-circle" style="width:80px; margin: 0 auto; padding-bottom: 10px;">
				<?php endif; ?>
				<h4 class="media-heading"><strong><?php echo e($user->name); ?></strong></h4>
			</div>
			<hr>
			<div class="text-center">
				<?php if(!empty($user->facebook)): ?>
				<a href="<?php echo e($user->facebook); ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-facebook"></i></a>
				<?php endif; ?>
				<?php if(!empty($user->twitter)): ?>
				<a href="<?php echo e($user->twitter); ?>" target="_blank" class="btn btn-info btn-sm"><i class="fa fa-twitter"></i></a>
				<?php endif; ?>
				<?php if(!empty($user->google_plus)): ?>
				<a href="<?php echo e($user->google_plus); ?>" target="_blank" class="btn btn-danger btn-sm"><i class="fa fa-google-plus"></i></a>
				<?php endif; ?>
				<?php if(!empty($user->linkedin)): ?>
				<a href="<?php echo e($user->linkedin); ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-linkedin"></i></a>
				<?php endif; ?>
			</div>
			<hr>
			<ul class="contact-widget">
				<li>
					<span>Username</span>
					<ins><i class="ti-user"></i> <?php echo e($user->username); ?></ins>
				</li>
				<li>
					<span>Email Address</span>
					<ins><i class="ti-email"></i> <?php echo e($user->email); ?></ins>
				</li>
				<?php if(!empty($user->phone)): ?>
				<li>
					<span>Phone Number</span>
					<ins><i class="ti-mobile"></i> <?php echo e($user->phone); ?></ins>
				</li>
				<?php endif; ?>
				<?php if(!empty($user->address)): ?>
				<li>
					<span>Address</span>
					<ins><i class="ti-location-pin"></i> <?php echo e($user->address); ?></ins>
				</li>
				<?php endif; ?>
				<?php if(!empty($user->gender)): ?>
				<li>
					<span>Gender</span>
					<?php if($user->gender == 'm'): ?>
					<ins><i class="fa fa-male"></i> Male</ins>
					<?php else: ?>
					<ins><i class="fa fa-female"></i> Female</ins>
					<?php endif; ?>
				</li>
				<?php endif; ?>
				<?php if(!empty($user->about)): ?>
				<li>
					<span>About</span>
					<ins><i class="ti-user"></i> <?php echo e($user->about); ?></ins>
				</li>
				<?php endif; ?>
			</ul>
		</div>
	</aside>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>