<?php $__env->startSection('title', 'My Blog'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.form-control{
    border-radius: 0px;
        padding: 20px 12px;
}
.btn{
    border-radius: 0px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-6 col-md-offset-3">
    <div class="home-news-block block-no-space">
        <div class="about-us">
            <h3>Login</h3>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email">Username / Email</label>
                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" autofocus>
                    <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password">Password</label>
                    <input id="password" type="password" class="form-control" name="password">
                    <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                    <button type="submit" class="btn btn-primary">Login</button> <a style="padding-left: 10px" href="<?php echo e(route('password.request')); ?>">Forget password?</a>
            </form>
            <p style="margin-top: 25px;">You have no account? <a href="<?php echo e(route('register')); ?>">Click here</a>.</p>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>