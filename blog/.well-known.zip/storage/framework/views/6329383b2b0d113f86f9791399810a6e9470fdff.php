
<?php $__env->startSection('title', 'Update Profile'); ?>


<?php $__env->startSection('style'); ?>
<style type="text/css">
.form-control{
	border-radius: 0px;
	padding: 20px 12px;
}
.btn{
	border-radius: 0px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="home-news-block block-no-space">
		<div class="crumb inner-page-crumb">
			<ul>
				<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
				<li><a href="<?php echo e(route('dashboard.dashboardPage')); ?>">Dashboard</a> / </li>
				<li><a href="<?php echo e(route('dashboard.editProfilePage')); ?>">Edit Profile</a></li>
			</ul>
		</div>

		<?php ($user = Auth::user()); ?>

		<div class="about-us">
			<h3>Edit Profile</h3>
			<div class="row">
				<div class="col-sm-12">
					<?php if(!empty(Session::get('message'))): ?>
					<p style="color: #5cb85c"><?php echo e(Session::get('message')); ?></p>
					<?php elseif(!empty(Session::get('exception'))): ?>
					<p style="color: #d9534f"><?php echo e(Session::get('exception')); ?></p>
					<?php else: ?>
					<p>Required fields are marked <span class="required">*</span></p>
					<?php endif; ?>
				</div>
				<div class="col-sm-12">
				<form data-parsley-validate name="profile_edit_form" action="<?php echo e(route('dashboard.updatePprofilePage', $user->id)); ?>" method="post" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name">Name</label>
                    <input type="text" name="name" class="form-control" id="name" value="<?php echo e($user->name); ?>" placeholder="ex: name">
                    <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                    <label for="username">Username</label>
                    <input type="text" name="username" class="form-control" id="username" value="<?php echo e($user->username); ?>" placeholder="ex: username">
                    <?php if($errors->has('username')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" id="email" value="<?php echo e($user->email); ?>" placeholder="ex: example@gmail.com">
                    <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
					<div class="form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
						<label>Gender <span class="required">*</span></label>
						<select name="gender" id="gender" class="form-control" required>
							<option value="">Select One</option>
							<option value="m">Male</option>
							<option value="f">Female</option>
						</select>
						<?php if($errors->has('gender')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('gender')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
						<label>Phone <span class="required">*</span></label>
						<input id="phone" type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>" required maxlength="25" placeholder="ex: xxxxxxxxxxxx">
						<?php if($errors->has('phone')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('phone')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
						<label>Address <span class="required">*</span></label>
						<input id="address" type="text" name="address" class="form-control" value="<?php echo e($user->address); ?>" required maxlength="250" placeholder="ex: address">
						<?php if($errors->has('address')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('address')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('facebook') ? ' has-error' : ''); ?>">
						<label>Facebook</label>
						<input id="facebook" type="text" name="facebook" class="form-control" value="<?php echo e($user->facebook); ?>" maxlength="250" placeholder="ex: https://facebook.com">
						<?php if($errors->has('facebook')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('facebook')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('twitter') ? ' has-error' : ''); ?>">
						<label>Twitter</label>
						<input id="twitter" type="text" name="twitter" class="form-control" value="<?php echo e($user->twitter); ?>" maxlength="250" placeholder="ex: https://twitter.com">
						<?php if($errors->has('twitter')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('twitter')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('google_plus') ? ' has-error' : ''); ?>">
						<label>Google Plus</label>
						<input id="google_plus" type="text" name="google_plus" class="form-control" value="<?php echo e($user->google_plus); ?>" maxlength="250" placeholder="ex: https://plus.google.com">
						<?php if($errors->has('google_plus')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('google_plus')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('linkedin') ? ' has-error' : ''); ?>">
						<label>Linkedin</label>
						<input id="linkedin" type="text" name="linkedin" class="form-control" value="<?php echo e($user->linkedin); ?>" maxlength="250" placeholder="ex: https://linkedin.com">
						<?php if($errors->has('linkedin')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('linkedin')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('avatar') ? ' has-error' : ''); ?>">
						<label>Profile Picture</label>
						<input id="avatar" type="file" name="avatar" class="form-control">
						<?php if($errors->has('avatar')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('avatar')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="form-group<?php echo e($errors->has('about') ? ' has-error' : ''); ?>">
						<label>About <span class="required">*</span></label>
						<textarea name="about" rows="5" class="form-control" required maxlength="260" placeholder="ex: about me"><?php echo e($user->about); ?></textarea>
						<?php if($errors->has('about')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('about')); ?></strong>
						</span>
						<?php endif; ?>
					</div>
					<div class="col-sm-12">
						<button type="submit" class="btn btn-primary">Update</button>
					</div>
				</form>
			</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.user_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
	document.forms['profile_edit_form'].elements['gender'].value = "<?php echo e($user->gender); ?>";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>