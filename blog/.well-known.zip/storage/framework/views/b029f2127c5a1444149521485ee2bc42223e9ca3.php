<?php $__env->startSection('title', 'Search'); ?>


<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
			<li><a class="active">Search Results</a></li>
		</ul>
	</div>
	<?php if($posts->count() > 0): ?>
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="faqs-title">
		<a href="<?php echo e(route('detailsPage', $post->post_slug)); ?>" title="<?php echo e($post->post_title); ?>"><h4><?php echo e($post->post_title); ?></h4></a>
		<div class="single-post-info" style="margin-bottom: 15px; border-bottom: 1px solid #ddd; padding: 10px 0px;">
			<div class="pull-left post-author">
				<?php if(!empty($post->user->avatar)): ?>
				<img alt="<?php echo e($post->user->name); ?>" src="<?php echo e(asset('public/avatar/' . $post->user->avatar)); ?>" width="35px">
				<?php else: ?>
				<img alt="<?php echo e($post->user->name); ?>" src="<?php echo e(get_gravatar($post->user->email)); ?>" width="35px">
				<?php endif; ?>
				By <a href="<?php echo e(route('authorProfilePage', $post->user->username)); ?>" title=""><?php echo e($post->user->name); ?></a>
				<span class="spliator">ــ</span>
				Last Update <a><?php echo e(date("d F Y", strtotime($post->post_date))); ?></a>
			</div>

			<ul class="views-comments pull-right">
				<li class="po-views"><i class="fa fa-eye"></i><?php echo e($post->view_count); ?></li>
				<li><i class="fa fa-comments"></i><?php echo e($post->comment->count()); ?></li>
			</ul>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
	<div class="text-center">No Result</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>