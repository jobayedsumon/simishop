<?php $__env->startSection('title', $page->meta_title); ?>
<?php $__env->startSection('keywords', $page->meta_keywords); ?>
<?php $__env->startSection('description', $page->meta_description); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
			<li><a class="active"><?php echo e($page->page_name); ?></a></li>
		</ul>
	</div>
	<div class="about-us">
		<h3><?php echo e($page->page_name); ?></h3>
		<?php if(!empty($page->page_featured_image)): ?>
			<img src="<?php echo e(get_page_featured_image_url($page->page_featured_image)); ?>" alt="<?php echo e($page->page_name); ?>">
			<?php endif; ?>
		<div class="about-meta">
		<p><?php echo $page->page_content; ?></p>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>