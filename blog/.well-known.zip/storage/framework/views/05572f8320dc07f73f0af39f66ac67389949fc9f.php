<header class="header-menu">
    <!--START TOP BAR-->
    <div class="top-bar">
        <div class="container">
            <div class="sub-top-bar">
                <div class="current-time">
                    <span><small><?php echo e(date("D d F Y", strtotime(now()))); ?></small></span>
                </div>
                <!--<div class="tracking-news">
                    <div class="panel panel-default">
                        <span class="breaking-title"> <span class="fa fa-bolt" aria-hidden="true"></span> <span class="breaking-title-text">Trending News</span> </span>
                        <div class="panel-body">
                            <ul class="demo1">
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                                <li class="news-item">
                                    <p><a href="single-post-default.html">Lorem ipsum dolor sit amet, consectetur adipiscing elit sit amet...</a></p>
                                </li>
                            </ul>
                        </div>
                        <div class="panel-footer"> </div>
                    </div>
                </div>-->
                <div id="login-register">
                    <?php if(Auth::check()): ?>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span> Logout</span></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                    <a href="<?php echo e(route('dashboard.dashboardPage')); ?>"> Dashboard</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"><span> Login</span></a>
                    <a href="<?php echo e(route('register')); ?>"><span> Register</span></a>
                    <?php endif; ?>
                    <ul class="social-btns">
                        <?php if(!empty($setting->facebook)): ?>
                        <li><a href="<?php echo e($setting->facebook); ?>" target="_blank" title="<?php echo e($setting->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($setting->twitter)): ?>
                        <li><a href="<?php echo e($setting->twitter); ?>" target="_blank" title="<?php echo e($setting->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($setting->google_plus)): ?>
                        <li><a href="<?php echo e($setting->google_plus); ?>" target="_blank" title="<?php echo e($setting->google_plus); ?>"><i class="fa fa-google-plus"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($setting->linkedin)): ?>
                        <li><a href="<?php echo e($setting->linkedin); ?>" target="_blank" title="<?php echo e($setting->linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--/END TOP BAR-->

    <!--START BOTTOM HEADER-->
    <div class="logo-bar">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="logo">
                        <a aria-hidden="true" title="<?php echo e($setting->website_title); ?>" href="<?php echo e(route('homePage')); ?>"><img alt="<?php echo e($setting->website_title); ?>" src="<?php echo e(asset('public/web/logo/' . $setting->logo)); ?>"></a>
                    </div>
                </div>
                <div class="col-sm-9">
                    <!-- <div class="ad"><a href="#" title="Maro News"><img  alt="maro-news" src="<?php echo e(asset('public/web')); ?>/images/uploads/ad.jpg"></a></div> -->
                </div>
            </div>
        </div>
    </div><!-- Logo Bar -->

    <!-- Menu Bar -->
    <?php echo $__env->make('web.includes.menubar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Menu Bar -->

    <!--?END BOTTOM HEADER-->
</header>


<!--START RESPONSIVE HEADER-->
<div class="responsive-header">
    <div class="res-logo-area">
        <div class="col-sm-9 col-xs-8">
            <a href="<?php echo e(route('homePage')); ?>" title="Maro News"><img src="<?php echo e(asset('public/web/images/logo.png')); ?>" alt="<?php echo e($setting->website_title); ?>"></a>
        </div>
        <div class="col-sm-3 col-xs-4">
            <div id="nav-icons-head">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <div class="responsive-menu">
        <a href="<?php echo e(route('homePage')); ?>" title="<?php echo e($setting->website_title); ?>"><img src="<?php echo e(asset('public/web/images/logo.png')); ?>" alt="maro-news"></a>
        <ul>
            <li><a href="<?php echo e(route('homePage')); ?>" title="<?php echo e($setting->website_title); ?>">Home</a></li>
            <li><a href="<?php echo e(route('mostPopularPage')); ?>" title="Most Popular">Most Popular</a></li>
            <li><a href="<?php echo e(route('tagsPage')); ?>" title="Tags">Tags</a></li>
            <li><a href="<?php echo e(route('categoriesPage')); ?>" title="Categories">Categories</a></li>
            <li><a href="<?php echo e(route('galleryPage')); ?>" title="Categories">Gallery</a></li>
            <li><a href="<?php echo e(route('contactUsPage')); ?>" title="Contact Us">Contact Us</a></li>
            <?php if(Auth::check()): ?>
            <li><a href="<?php echo e(route('dashboard.dashboardPage')); ?>"> <span style="color: #007bbd">Dashboard</span></a></li>
            <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><span style="color: #007bbd"> Logout</span></a></li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
            <?php else: ?>
            <li><a href="<?php echo e(route('login')); ?>"><span style="color: #007bbd"> Login</span></a></li>
            <li><a href="<?php echo e(route('register')); ?>"><span style="color: #007bbd"> Register</span></a></li>
            <?php endif; ?>
        </ul>
        <div class="res-social">
            Follow US:
            <br>
            <ul class="social-btns">
                <?php if(!empty($setting->facebook)): ?>
                <li><a href="<?php echo e($setting->facebook); ?>" target="_blank" title="<?php echo e($setting->facebook); ?>"><i class="fa fa-facebook"></i></a></li>
                <?php endif; ?>
                <?php if(!empty($setting->twitter)): ?>
                <li><a href="<?php echo e($setting->twitter); ?>" target="_blank" title="<?php echo e($setting->twitter); ?>"><i class="fa fa-twitter"></i></a></li>
                <?php endif; ?>
                <?php if(!empty($setting->google_plus)): ?>
                <li><a href="<?php echo e($setting->google_plus); ?>" target="_blank" title="<?php echo e($setting->google_plus); ?>"><i class="fa fa-google-plus"></i></a></li>
                <?php endif; ?>
                <?php if(!empty($setting->linkedin)): ?>
                <li><a href="<?php echo e($setting->linkedin); ?>" target="_blank" title="<?php echo e($setting->linkedin); ?>"><i class="fa fa-linkedin"></i></a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<!--/END RESPONSIVE HEADER-->