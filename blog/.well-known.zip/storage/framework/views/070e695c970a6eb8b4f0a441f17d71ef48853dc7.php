<?php $__env->startSection('title', 'My Blog'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="error-404">
        <a href="<?php echo e(route('homePage')); ?>">
            <img src="<?php echo e(asset('public/web/images/404.png')); ?>">
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>