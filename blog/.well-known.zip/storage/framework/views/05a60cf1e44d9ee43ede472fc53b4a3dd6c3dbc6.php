<?php $__env->startSection('title', $setting->meta_title); ?>
<?php $__env->startSection('keywords', $setting->meta_keywords); ?>
<?php $__env->startSection('description', $setting->meta_description); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-8">
	<div class="crumb inner-page-crumb">
		<ul>
			<li><i class="ti-home"></i><a href="<?php echo e(route('homePage')); ?>">Home</a> / </li>
		</ul>
	</div>
	<div class="home-news-block block-no-space">
		<!--<div class="home-posts-head">
			<h4 class="home-posts-cat-title"><a class="cat-3" href="#">What's New</a></h4>
		</div>-->
		<div class="row postgrid-horiz grid-style-2">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-sm-6">
				<div class="post-grid-style">
					<div class='post-grid-image'>
						<a class="post-cat cat-1" href="<?php echo e(route('categoryPage', $post->category->id)); ?>" title="<?php echo e($post->category->category_name); ?>"><?php echo e($post->category->category_name); ?></a>
						<a class="grid-image" href="<?php echo e(route('detailsPage', $post->post_slug)); ?>" title="<?php echo e($post->post_title); ?>">
							<img src="<?php echo e(get_featured_image_thumbnail_url($post->featured_image)); ?>" alt="<?php echo e($post->post_title); ?>">
						</a>
					</div>

					<div class="post-detail">
						<h2><a href="<?php echo e(route('detailsPage', $post->post_slug)); ?>" title="<?php echo e($post->post_title); ?>"><?php echo e(str_limit($post->post_title, 44)); ?></a></h2>
						<ul class="post-meta3 pull-left">
							<li><i class="ti-time"></i><a><?php echo e(date("d F Y", strtotime($post->post_date))); ?></a></li>
							<li class="admin"><a href="<?php echo e(route('authorProfilePage', $post->user->username)); ?>"><i class="ti-user"></i> <?php echo e($post->user->name); ?></a></li>
						</ul>
						<ul class="post-meta3 pull-right">
							<li><i class="fa fa-eye"></i><a title="<?php echo e($post->post_title); ?>"><?php echo e($post->view_count); ?></a></li>
							<li><a title="<?php echo e($post->post_title); ?>"><i class="fa fa-comments"></i> <?php echo e($post->comment->count()); ?></a></li>
						</ul>
						<?php echo str_limit($post->post_details, 120); ?>

						<a href="<?php echo e(route('detailsPage', $post->post_slug)); ?>" class="readmore" title="<?php echo e($post->post_title); ?>"><i class="ti-more-alt"></i></a>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="pagination"><?php echo e($posts->links()); ?></div>
	</div>

	<div class="single-related">
		<div class="single-title">
			<h4><i class="fa fa-thumbs-o-up"></i> Most Popular Posts</h4>
		</div>
		<div class="category-recent-post">
			<?php $__currentLoopData = $popular_posts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="progress-unit">
				<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 col-sm-12">
					<div class="pp-trending-grid">
						<img src="<?php echo e(get_featured_image_thumbnail_url($popular_post->featured_image)); ?>" alt="maro news">
						<div class="pp-trend-meta">
							<h5><a href="<?php echo e(route('detailsPage', $popular_post->post_slug)); ?>" title=""><?php echo e(str_limit($popular_post->post_title, 50)); ?></a></h5>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('web.includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>