<!--START BOTTOM BAR-->
<div class="bottom-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 text-left">
                <p class="copyright"><?php echo $setting->copyright; ?></p>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6 text-right">
                <div class="footer-imp-links">
                    <a href="<?php echo e(route('homePage')); ?>">Home</a>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('pagePage', $page->page_slug)); ?>"><?php echo e($page->page_name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!--END BOTTOM BAR-->