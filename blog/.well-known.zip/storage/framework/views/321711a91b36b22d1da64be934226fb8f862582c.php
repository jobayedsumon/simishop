<!DOCTYPE html>
<html lang="en">
<!-- head -->
<head>
    <?php echo $__env->make('web.includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<!-- /.head -->

<body>
    <!-- theme layout -->
    <div class="theme-layout">
        <!-- header -->
        <?php echo $__env->make('web.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /.header -->

        <!-- first section block -->
        <section>
            <div class="space">
                <div class="container">
                    <div class="row">
                        <!-- left section -->
                        <?php echo $__env->yieldContent('content'); ?>
                        <!-- /. left section -->

                        <!-- /. right side widget -->
                        <?php echo $__env->yieldContent('sidebar'); ?>
                        <!--/. right side widget-->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.first section block -->

        <!-- footer -->
        <?php echo $__env->make('web.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- /. footer -->

    </div>
    <!-- /. theme-layout -->

    <!-- scripts -->
    <?php echo $__env->make('web.includes.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
    <!-- /. script -->
</body>
</html>